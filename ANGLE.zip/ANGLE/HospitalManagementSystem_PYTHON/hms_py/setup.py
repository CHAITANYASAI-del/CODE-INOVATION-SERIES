from distutils.core import setup

setup(
    name='HospitalManagementSystem',
    version='2.7',
    packages=['package'],
    url='',
    license='',
    author='CHAITANYA SAI (uzumaki)',
    author_email='tusharborole@ymail.com',
    description='HospitalManagementSystem for college python course'
)
